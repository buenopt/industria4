<?php
header('Location: View/_pages/inicio.php');
?>