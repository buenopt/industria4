<?php
header('Location: ../View/_pages/passo1.php');
?>